# TODO: Implémenter modal d'album d'images pour les projets

## Étapes à suivre :
- [ ] Ajouter la structure HTML du modal dans index.html
- [ ] Ajouter les styles CSS du modal dans Style.css
- [ ] Modifier Script.js pour gérer l'ouverture du modal avec les images appropriées
- [ ] Changer les liens "Code" pour déclencher le modal
- [ ] Tester le modal pour chaque projet
- [ ] Vérifier que les images se chargent correctement
